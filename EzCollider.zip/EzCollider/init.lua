EzCollider = {_VERSION = "EzCollider 1.12", _DESCRIPTION = "Simple and easy Collider for LÖVE", path = ...}
EzCollider.Collider = require(EzCollider.path.."/Collider")
local EzCollider = EzCollider
_G.EzCollider = nil
return EzCollider
